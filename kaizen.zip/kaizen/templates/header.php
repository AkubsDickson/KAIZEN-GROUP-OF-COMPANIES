<!-- Header for all pages -->
<!DOCTYPE html>
<html>

<head>
  <title>KAIZEN</title>
  <link rel="stylesheet" href="css/style.css" />
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">
</head>

<body>
  <div>

  <!-- Navigation Bar -->
  <nav>
    <div class="nav-wrapper teal darken-4">
      <a id="top" href="index.php" class="brand-logo" style="font-family:Roboto"><i class="large material-icons">arrow_back</i>BACK</a>
      </div>
    </nav>
  </div>

  <!--Line Beneath Nav Bar-->
  <div class="col s12 grey lighten-3" style="height:5px"></div><br>

  </body>
</html>




