<!-- Adding header template to page -->
<?php include "templates/header.php"; ?>

<h4>Patient Diagnosis</h4>

<!-- Table of all patient records -->
<div class="container">
  <table class="responsive-table highlight">
    <thead>
      <tr>
          <th>Patient ID</th>
          <th>Diagnosis Name</th>
          <th>Brand Name</th>
          <th>Generic Name</th>
      </tr>
    </thead>

 <?php

	 // Include config file
	 require_once "config.php";

	// SQL Query
	$sql = "SELECT Patient.patient_id, Diagnosis.diagnosis_name, Medication.brand_name, Medication.generic_name FROM Patient INNER JOIN Patient_Diagnosis ON Patient.patient_id = Patient_Diagnosis.patient_id INNER JOIN Diagnosis ON Patient_Diagnosis.diagnosis_id = Diagnosis.diagnosis_id INNER JOIN Patient_Medication ON Patient.patient_id = Patient_Medication.patient_id INNER JOIN Medication ON Patient_Medication.medication_id = Medication.medication_id";

	//Instance of the query
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
	  // output data of each row
	  while($row = $result->fetch_assoc()) {
	    echo "<tr><td>" . $row["patient_id"]. "</td><td>" . $row["diagnosis_name"]. "</td><td>" . $row["brand_name"]. "</td><td>" . $row["generic_name"]. "</td><tr>";

	  }
	} else {
	  echo "0 results";
	}
	$conn->close();
?>

  </table>
</div><br>
