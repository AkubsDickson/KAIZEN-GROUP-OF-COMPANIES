<!-- Adding header template to page -->
<?php include "templates/header.php"; ?>

<h4>Discharged Patients</h4>

<!-- Table of all patient records -->
<div class="container">
  <table class="responsive-table highlight">
    <thead>
      <tr>
          <th>Patient ID</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Discharge Date</th>
          <th>Bill Status</th>
      </tr>
    </thead>

 <?php

	 // Include config file
	 require_once "config.php";

	// SQL Query
	$sql = "SELECT Patient.patient_id, Outpatient.date_of_discharge, Outpatient.bill_status, Person.first_name, Person.last_name FROM Patient INNER JOIN Outpatient ON Patient.patient_id = Outpatient.patient_id INNER JOIN Person ON Person.person_id = Patient.person_id";

	//Instance of the query
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
	  // output data of each row
	  while($row = $result->fetch_assoc()) {
	    echo "<tr><td>" . $row["patient_id"]. "</td><td>" . $row["first_name"]. "</td><td>" . $row["last_name"]. "</td><td>" . $row["date_of_discharge"]. "</td><td>" . $row["bill_status"]. "</td><tr>";

	  }
	} else {
	  echo "0 results";
	}
	$conn->close();
?>

  </table>
</div><br>
