<!-- Index page -->
<!DOCTYPE html>
<html>

<head>
  <title>KAIZEN</title>
  <link rel="stylesheet" href="css/style.css" />
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">
</head>

<body>
<div>
  <nav>
    <div class="nav-wrapper teal darken-4">
      <a id="top" href="index.html" class="brand-logo center" style="font-family:Roboto">KAIZEN GROUP OF COMPANIES</a>
    </div>
  </nav>
</div>

<!--Line Beneath Nav Bar-->
<div class="col s12 grey lighten-3" style="height:5px"></div><br>

<!-- Page Header -->
<h4>Nyaho Medical</h4>

<!-- Links -->
<div class="container">

  <!-- Column One -->
  <div class="row">
    <div class="col s6">

      <div class="divider"></div>
        <div class="section">
          <h5>1. Empty Rooms</h5>
          <p><a href="empty-rooms.php">View Empty Rooms</a></p>
        </div>

      <div class="divider"></div>
        <div class="section">
          <h5>3. Covid-Tested</h5>
          <p><a href="covid-tested.php">View Covid-Tested Patients</a></p>
        </div>

      <div class="divider"></div>
        <div class="section">
          <h5>5. Discharged</h5>
          <p><a href="discharged-patients.php">View Discharged Patients</a></p>
        </div>
      </div>

  <!-- Column Two -->
  <div class="col s6">

    <div class="divider"></div>
      <div class="section">
        <h5>2. Malaria Patients</h5>
        <p><a href="malaria-patients.php">View Malaria Patients</a></p>
      </div>

    <div class="divider"></div>
      <div class="section">
        <h5>4. Patient Diagnosis</h5>
        <p><a href="patient-diagnosis.php">View Patients' Diagnosis</a></p>
      </div>

    <div class="divider"></div>
      <div class="section">
        <h5>6. Appointments</h5>
        <p><a href="doctor-appointments.php">View Doctors' Appointments</a></p>
      </div>
    </div>
  </div>
</div>

</body>
</html>


   