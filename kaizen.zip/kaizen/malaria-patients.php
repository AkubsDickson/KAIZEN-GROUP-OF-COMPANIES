<!-- Adding header template to page -->
<?php include "templates/header.php"; ?>

<h4>Malaria Patients</h4>

<!-- Table of all patient records -->
<div class="container">
  <table class="responsive-table highlight">
    <thead>
      <tr>
          <th>Patient ID</th>
          <th>Name</th>
          <th>Surname</th>
      </tr>
    </thead>

 <?php

	 // Include config file
	 require_once "config.php";
	
	// SQL Query
	$sql = "SELECT Patient.patient_id, Person.first_name, Person.last_name FROM Patient JOIN Person ON Patient.person_id = Person.person_id JOIN Patient_Diagnosis ON Patient.patient_id = Patient_Diagnosis.patient_id JOIN Diagnosis ON Patient_Diagnosis.diagnosis_id = Diagnosis.diagnosis_id WHERE Diagnosis.diagnosis_name = 'malaria'";
	
	//Instance of the query
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
	  // output data of each row
	  while($row = $result->fetch_assoc()) {
	    echo "<tr><td>" . $row["patient_id"]. "</td><td>" . $row["first_name"]. "</td><td>" . $row["last_name"]. "</td><tr>";

	  }
	} else {
	  echo "0 results";
	}
	$conn->close();
?>

  </table>
</div><br>
