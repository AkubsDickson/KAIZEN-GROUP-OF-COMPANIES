<!-- Adding header template to page -->
<?php include "templates/header.php"; ?>

<h4>Covid-Tested Patients</h4>

<!-- Table of all patient records -->
<div class="container">
  <table class="responsive-table highlight">
    <thead>
      <tr>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Gender</th>
          <th>Phone Number</th>
          <th>Email</th>
      </tr>
    </thead>

 <?php

	 // Include config file
	 require_once "config.php";

	// SQL Query
	$sql = "SELECT Person.first_name, Person.last_name, Person.gender, Person.phone_number, Person.email FROM Person INNER JOIN Covid_Test ON Person.person_id = Covid_Test.person_id WHERE Covid_Test.has_tested = TRUE AND Covid_Test.test_status = 'positive' AND Person.phone_number IS NOT NULL";

	//Instance of the query
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
	  // output data of each row
	  while($row = $result->fetch_assoc()) {
	    echo "<tr><td>" . $row["first_name"]. "</td><td>" . $row["last_name"]. "</td><td>" . $row["gender"]. "</td><td>" . $row["phone_number"]. "</td><td>" . $row["email"]. "</td><tr>";

	  }
	} else {
	  echo "0 results";
	}
	$conn->close();
?>

  </table>
</div><br>
