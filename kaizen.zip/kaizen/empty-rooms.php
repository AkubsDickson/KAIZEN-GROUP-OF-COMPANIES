<!-- Adding header template to page -->
<?php include "templates/header.php"; ?>

<h4>Empty Rooms</h4>

<!-- Table of all patient records -->
<div class="container">
  <table class="responsive-table highlight">
    <thead>
      <tr>
          <th>Ward Name</th>
          <th>Ward ID</th>
          <th>Room Type</th>
          <th>Room Status</th>
      </tr>
    </thead>

 <?php

	 // Include config file
	 require_once "config.php";

	// SQL Query
	$sql = "SELECT Ward.ward_name, Room.room_id, Room.room_type, Room.room_status FROM Ward INNER JOIN Room ON Ward.ward_id = Room.ward_id ORDER BY Room.room_status ASC";

	//Instance of the query
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
	  // output data of each row
	  while($row = $result->fetch_assoc()) {
	    echo "<tr><td>" . $row["ward_name"]. "</td><td>" . $row["room_id"]. "</td><td>" . $row["room_type"]. "</td><td>" . $row["room_status"]. "</td><tr>";

	  }
	} else {
	  echo "0 results";
	}
	$conn->close();
?>

  </table>
</div><br>
